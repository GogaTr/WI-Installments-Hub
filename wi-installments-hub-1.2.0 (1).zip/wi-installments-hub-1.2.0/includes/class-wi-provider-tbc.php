<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WI_Provider_TBC implements WI_Provider_Interface {
    const OPTION_KEY = 'wi_installments_hub_settings';

    private $logger;
    private $settings;

    public function __construct( WI_Installments_Logger $logger ) {
        $this->logger = $logger;
        $this->load_settings();
    }

    private function load_settings() {
        $this->settings = get_option( self::OPTION_KEY, [] );
    }

    public function get_key() {
        return 'tbc';
    }

    public function get_label() {
        return 'TBC';
    }

    public function is_enabled() {
        return true;
    }

    public function get_mode() {
        $this->load_settings();
        return ! empty( $this->settings['mode'] ) && in_array( $this->settings['mode'], [ 'test', 'production' ], true )
            ? $this->settings['mode']
            : 'test';
    }

    public function get_base_url() {
        return 'production' === $this->get_mode() ? 'https://api.tbcbank.ge' : 'https://test-api.tbcbank.ge';
    }

    public function get_api_key() {
        $this->load_settings();
        return isset( $this->settings['tbc_api_key'] ) ? trim( (string) $this->settings['tbc_api_key'] ) : '';
    }

    public function get_api_secret() {
        $this->load_settings();
        return isset( $this->settings['tbc_api_secret'] ) ? trim( (string) $this->settings['tbc_api_secret'] ) : '';
    }

    public function get_merchant_key() {
        $this->load_settings();
        return isset( $this->settings['tbc_merchant_key'] ) ? trim( (string) $this->settings['tbc_merchant_key'] ) : '';
    }

    public function get_campaign_id() {
        $this->load_settings();
        return isset( $this->settings['tbc_campaign_id'] ) ? trim( (string) $this->settings['tbc_campaign_id'] ) : '';
    }

    private function normalize_headers_for_log( $headers ) {
        if ( is_object( $headers ) && method_exists( $headers, 'getAll' ) ) {
            $headers = $headers->getAll();
        }

        return is_array( $headers ) ? $headers : [];
    }

    private function extract_redirect_url( $headers_response, $body = [], $body_raw = '' ) {
        $location = '';

        if ( is_object( $headers_response ) ) {
            if ( method_exists( $headers_response, 'get' ) ) {
                $location = (string) $headers_response->get( 'location' );
            }

            if ( empty( $location ) && method_exists( $headers_response, 'getAll' ) ) {
                $all_headers = $headers_response->getAll();
                foreach ( [ 'location', 'Location' ] as $key ) {
                    if ( ! empty( $all_headers[ $key ] ) ) {
                        $location = is_array( $all_headers[ $key ] ) ? (string) reset( $all_headers[ $key ] ) : (string) $all_headers[ $key ];
                        break;
                    }
                }
            }
        } elseif ( is_array( $headers_response ) ) {
            foreach ( [ 'location', 'Location' ] as $key ) {
                if ( ! empty( $headers_response[ $key ] ) ) {
                    $location = is_array( $headers_response[ $key ] ) ? (string) reset( $headers_response[ $key ] ) : (string) $headers_response[ $key ];
                    break;
                }
            }
        }

        foreach ( [ 'location', 'redirectUrl', 'redirect_url', 'url' ] as $key ) {
            if ( empty( $location ) && ! empty( $body[ $key ] ) ) {
                $location = (string) $body[ $key ];
            }
        }

        if ( empty( $location ) && is_string( $body_raw ) && preg_match( "#https?://[^\\s\"']+#", $body_raw, $matches ) ) {
            $location = (string) $matches[0];
        }

        $location = trim( $location );
        return filter_var( $location, FILTER_VALIDATE_URL ) ? $location : '';
    }

    public function create_application( array $data ) {
        $token = $this->get_access_token();
        if ( is_wp_error( $token ) ) {
            return $token;
        }

        $endpoint = trailingslashit( $this->get_base_url() ) . 'v1/online-installments/applications';
        $payload  = [
            'merchantKey' => $this->get_merchant_key(),
            'campaignId'  => $this->get_campaign_id(),
            'invoiceId'   => $data['invoice_id'],
            'priceTotal'  => number_format( (float) $data['price_total'], 2, '.', '' ),
            'products'    => [
                [
                    'name'     => $data['product_name'],
                    'price'    => number_format( (float) $data['price_total'], 2, '.', '' ),
                    'quantity' => (int) $data['quantity'],
                ],
            ],
        ];

        $headers = [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
        ];

        $response = wp_remote_post(
            $endpoint,
            [
                'timeout'     => 30,
                'redirection' => 0,
                'headers'     => $headers,
                'body'        => wp_json_encode( $payload ),
            ]
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code             = (int) wp_remote_retrieve_response_code( $response );
        $body_raw         = wp_remote_retrieve_body( $response );
        $body             = json_decode( $body_raw, true );
        $headers_response = wp_remote_retrieve_headers( $response );
        $location         = $this->extract_redirect_url( $headers_response, is_array( $body ) ? $body : [], $body_raw );

        if ( $code < 200 || $code >= 400 ) {
            return new WP_Error(
                'wi_tbc_create_failed',
                'TBC create application failed. HTTP ' . $code,
                [
                    'response_code'    => $code,
                    'response_body'    => $body_raw,
                    'response_headers' => $this->normalize_headers_for_log( $headers_response ),
                    'request_payload'  => $payload,
                    'request_url'      => $endpoint,
                ]
            );
        }

        return [
            'request_url'       => $endpoint,
            'request_method'    => 'POST',
            'request_headers'   => $headers,
            'request_payload'   => $payload,
            'response_code'     => $code,
            'response_body'     => is_array( $body ) ? $body : [],
            'response_body_raw' => $body_raw,
            'response_headers'  => $this->normalize_headers_for_log( $headers_response ),
            'session_id'        => ! empty( $body['sessionId'] ) ? (string) $body['sessionId'] : '',
            'redirect_url'      => $location,
        ];
    }

    public function get_application_status( array $request ) {
        $session_id = isset( $request['session_id'] ) ? (string) $request['session_id'] : '';
        if ( '' === $session_id ) {
            return new WP_Error( 'wi_tbc_missing_session_id', 'TBC session ID is missing.' );
        }

        $token = $this->get_access_token();
        if ( is_wp_error( $token ) ) {
            return $token;
        }

        $endpoint = trailingslashit( $this->get_base_url() ) . 'v1/online-installments/applications/' . rawurlencode( $session_id ) . '/status';
        $headers  = [
            'Authorization' => 'Bearer ' . $token,
            'Accept'        => 'application/json',
        ];

        $response = wp_remote_get(
            $endpoint,
            [
                'timeout'     => 30,
                'redirection' => 0,
                'headers'     => $headers,
            ]
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code             = (int) wp_remote_retrieve_response_code( $response );
        $body_raw         = wp_remote_retrieve_body( $response );
        $body             = json_decode( $body_raw, true );
        $headers_response = wp_remote_retrieve_headers( $response );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'wi_tbc_status_failed',
                'TBC get status failed. HTTP ' . $code,
                [
                    'response_code'    => $code,
                    'response_body'    => $body_raw,
                    'response_headers' => $this->normalize_headers_for_log( $headers_response ),
                    'request_url'      => $endpoint,
                ]
            );
        }

        return [
            'request_url'       => $endpoint,
            'request_method'    => 'GET',
            'request_headers'   => $headers,
            'response_code'     => $code,
            'response_body'     => is_array( $body ) ? $body : [],
            'response_body_raw' => $body_raw,
            'response_headers'  => $this->normalize_headers_for_log( $headers_response ),
        ];
    }

    private function get_access_token() {
        $api_key      = $this->get_api_key();
        $api_secret   = $this->get_api_secret();
        $merchant_key = $this->get_merchant_key();
        $campaign_id  = $this->get_campaign_id();

        if ( '' === $api_key || '' === $api_secret || '' === $merchant_key || '' === $campaign_id ) {
            return new WP_Error( 'wi_tbc_missing_settings', 'TBC settings are incomplete. Fill API Key, API Secret, Merchant Key and Campaign ID.' );
        }

        $endpoint = trailingslashit( $this->get_base_url() ) . 'oauth/token';
        $auth     = base64_encode( $api_key . ':' . $api_secret );

        $response = wp_remote_post(
            $endpoint,
            [
                'timeout'     => 30,
                'redirection' => 0,
                'headers'     => [
                    'Authorization' => 'Basic ' . $auth,
                    'Content-Type'  => 'application/x-www-form-urlencoded',
                    'Accept'        => 'application/json',
                ],
                'body'        => [
                    'grant_type' => 'client_credentials',
                    'scope'      => 'online_installments',
                ],
            ]
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code     = (int) wp_remote_retrieve_response_code( $response );
        $body_raw = wp_remote_retrieve_body( $response );
        $body     = json_decode( $body_raw, true );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'wi_tbc_token_failed',
                'TBC token request failed. HTTP ' . $code,
                [
                    'response_code' => $code,
                    'response_body' => $body_raw,
                    'request_url'   => $endpoint,
                ]
            );
        }

        if ( empty( $body['access_token'] ) ) {
            return new WP_Error( 'wi_tbc_token_missing', 'TBC access token was not returned.' );
        }

        return (string) $body['access_token'];
    }
}
