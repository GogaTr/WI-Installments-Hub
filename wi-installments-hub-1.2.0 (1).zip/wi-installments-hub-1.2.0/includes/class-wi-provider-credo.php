<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WI_Provider_Credo implements WI_Provider_Interface {
    const OPTION_KEY = 'wi_installments_hub_settings';

    private $logger;
    private $settings;

    public function __construct( WI_Installments_Logger $logger ) {
        $this->logger = $logger;
        $this->load_settings();
    }

    private function load_settings() {
        $this->settings = get_option( self::OPTION_KEY, [] );
    }

    public function get_key() {
        return 'credo';
    }

    public function get_label() {
        return 'Credo';
    }

    public function is_enabled() {
        $this->load_settings();
        return ! empty( $this->settings['credo_enabled'] );
    }

    public function get_mode() {
        return 'production';
    }

    public function get_merchant_key() {
        $this->load_settings();
        return isset( $this->settings['credo_merchant_id'] ) ? trim( (string) $this->settings['credo_merchant_id'] ) : '';
    }

    public function get_secret_password() {
        $this->load_settings();
        return isset( $this->settings['credo_secret_password'] ) ? (string) $this->settings['credo_secret_password'] : '';
    }

    public function get_create_url() {
        $this->load_settings();
        $url = isset( $this->settings['credo_create_url'] ) ? trim( (string) $this->settings['credo_create_url'] ) : '';
        return $url ? $url : 'https://ganvadeba.credo.ge/widget_api/order.php';
    }

    public function get_status_url() {
        $this->load_settings();
        $url = isset( $this->settings['credo_status_url'] ) ? trim( (string) $this->settings['credo_status_url'] ) : '';
        return $url ? $url : 'https://ganvadeba.credo.ge/widget/api.php';
    }

    private function unit_price_tetri( $price_total, $quantity ) {
        $quantity = max( 1, (int) $quantity );
        return (int) round( ( (float) $price_total / $quantity ) * 100 );
    }

    private function build_check( array $products, $secret ) {
        $string = '';
        foreach ( $products as $product ) {
            $string .= (string) $product['id'] . (string) $product['title'] . (string) $product['amount'] . (string) $product['price'] . (string) $product['type'];
        }
        return md5( $string . $secret );
    }

    private function build_status_hash( $merchant_id, $order_code, $secret ) {
        return md5( (string) $merchant_id . (string) $order_code . (string) $secret );
    }

    public function create_application( array $data ) {
        $merchant_id = $this->get_merchant_key();
        $secret = $this->get_secret_password();

        if ( '' === $merchant_id || '' === $secret ) {
            return new WP_Error( 'wi_credo_missing_settings', 'Credo settings are incomplete. Fill Merchant ID and Secret Password.' );
        }

        $product_name = isset( $data['product_name'] ) ? sanitize_text_field( $data['product_name'] ) : '';
        $price_total  = isset( $data['price_total'] ) ? (float) $data['price_total'] : 0;
        $quantity     = isset( $data['quantity'] ) ? max( 1, (int) $data['quantity'] ) : 1;
        $invoice_id   = isset( $data['invoice_id'] ) ? sanitize_text_field( $data['invoice_id'] ) : '';

        if ( '' === $product_name || $price_total <= 0 || '' === $invoice_id ) {
            return new WP_Error( 'wi_credo_invalid_payload', 'Credo request data is invalid.' );
        }

        $product_id = ! empty( $data['product_id'] ) ? sanitize_text_field( $data['product_id'] ) : $invoice_id;
        $unit_price_tetri = $this->unit_price_tetri( $price_total, $quantity );
        $products = [
            [
                'id'     => $product_id,
                'title'  => $product_name,
                'amount' => $quantity,
                'price'  => $unit_price_tetri,
                'type'   => 0,
            ],
        ];

        $payload = [
            'merchantId' => $merchant_id,
            'orderCode'  => $invoice_id,
            'check'      => $this->build_check( $products, $secret ),
            'products'   => $products,
        ];

        $endpoint = $this->get_create_url();
        $headers = [
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        ];

        $response = wp_remote_post(
            $endpoint,
            [
                'timeout'     => 30,
                'redirection' => 0,
                'headers'     => $headers,
                'body'        => wp_json_encode( $payload ),
            ]
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body_raw = wp_remote_retrieve_body( $response );
        $body = json_decode( $body_raw, true );
        $headers_response = wp_remote_retrieve_headers( $response );
        $redirect_url = '';

        if ( is_array( $body ) && ! empty( $body['data']['URL'] ) && filter_var( $body['data']['URL'], FILTER_VALIDATE_URL ) ) {
            $redirect_url = (string) $body['data']['URL'];
        }

        $api_status = is_array( $body ) && isset( $body['status'] ) ? (int) $body['status'] : null;
        if ( $code < 200 || $code >= 300 || 200 !== $api_status ) {
            return new WP_Error(
                'wi_credo_create_failed',
                'Credo create application failed. HTTP ' . $code,
                [
                    'response_code'    => $code,
                    'response_body'    => $body_raw,
                    'response_headers' => is_object( $headers_response ) && method_exists( $headers_response, 'getAll' ) ? $headers_response->getAll() : (array) $headers_response,
                    'request_payload'  => $payload,
                    'request_url'      => $endpoint,
                ]
            );
        }

        return [
            'request_url'       => $endpoint,
            'request_method'    => 'POST',
            'request_headers'   => $headers,
            'request_payload'   => $payload,
            'response_code'     => $code,
            'response_body'     => is_array( $body ) ? $body : [],
            'response_body_raw' => $body_raw,
            'response_headers'  => is_object( $headers_response ) && method_exists( $headers_response, 'getAll' ) ? $headers_response->getAll() : (array) $headers_response,
            'session_id'        => '',
            'redirect_url'      => $redirect_url,
        ];
    }

    public function get_application_status( array $request ) {
        $merchant_id = $this->get_merchant_key();
        $secret = $this->get_secret_password();
        $order_code = isset( $request['invoice_id'] ) ? (string) $request['invoice_id'] : '';

        if ( '' === $merchant_id || '' === $secret || '' === $order_code ) {
            return new WP_Error( 'wi_credo_missing_status_data', 'Credo status data is incomplete.' );
        }

        $hash = $this->build_status_hash( $merchant_id, $order_code, $secret );
        $endpoint = add_query_arg(
            [
                'merchantId' => $merchant_id,
                'orderCode'  => $order_code,
                'hash'       => $hash,
            ],
            $this->get_status_url()
        );

        $response = wp_remote_get(
            $endpoint,
            [
                'timeout'     => 30,
                'redirection' => 0,
                'headers'     => [ 'Accept' => 'application/json' ],
            ]
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body_raw = wp_remote_retrieve_body( $response );
        $body = json_decode( $body_raw, true );
        $headers_response = wp_remote_retrieve_headers( $response );
        $api_status = is_array( $body ) && isset( $body['status'] ) ? (int) $body['status'] : null;

        if ( $code < 200 || $code >= 300 || 200 !== $api_status ) {
            return new WP_Error(
                'wi_credo_status_failed',
                'Credo get status failed. HTTP ' . $code,
                [
                    'response_code'    => $code,
                    'response_body'    => $body_raw,
                    'response_headers' => is_object( $headers_response ) && method_exists( $headers_response, 'getAll' ) ? $headers_response->getAll() : (array) $headers_response,
                    'request_url'      => $endpoint,
                ]
            );
        }

        $status_id = isset( $body['data'] ) ? (int) $body['data'] : null;
        $status_map = [
            10 => 'NEED_IDENTIFICATION',
            2  => 'SENT',
            9  => 'SENT_TO_BRANCH',
            14 => 'SENT_TO_BACK_OFFICE_2',
            3  => 'APPROVED',
            4  => 'LATEST_APPROVED',
            12 => 'DOCUMENT_ASSIGNED',
            5  => 'CLOSED_SUCCESSFULLY',
            6  => 'REJECTED',
            7  => 'CANCELED',
            11 => 'DRAFT',
            13 => 'SENT_TO_VIDEO_MONITORING',
        ];

        if ( is_array( $body ) ) {
            $body['statusId'] = $status_id;
            $body['statusDescription'] = isset( $status_map[ $status_id ] ) ? $status_map[ $status_id ] : ( isset( $body['message'] ) ? (string) $body['message'] : '' );
        }

        return [
            'request_url'       => $endpoint,
            'request_method'    => 'GET',
            'request_headers'   => [ 'Accept' => 'application/json' ],
            'response_code'     => $code,
            'response_body'     => is_array( $body ) ? $body : [],
            'response_body_raw' => $body_raw,
            'response_headers'  => is_object( $headers_response ) && method_exists( $headers_response, 'getAll' ) ? $headers_response->getAll() : (array) $headers_response,
        ];
    }
}
