<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WI_Provider_BOG implements WI_Provider_Interface {

    const OPTION_KEY  = 'wi_installments_hub_settings';
    const AUTH_URL    = 'https://oauth2.bog.ge/auth/realms/bog/protocol/openid-connect/token';
    const ORDERS_URL  = 'https://api.bog.ge/payments/v1/ecommerce/orders';
    const RECEIPT_URL = 'https://api.bog.ge/payments/v1/receipt/';

    private $logger;
    private $settings;

    public function __construct( WI_Installments_Logger $logger ) {
        $this->logger = $logger;
        $this->load_settings();
    }

    private function load_settings() {
        $this->settings = get_option( self::OPTION_KEY, [] );
    }

    public function get_key() {
        return 'bog';
    }

    public function get_label() {
        return 'საქართველოს ბანკი';
    }

    public function is_enabled() {
        $this->load_settings();
        return ! empty( $this->settings['bog_enabled'] );
    }

    public function get_mode() {
        return 'production';
    }

    public function get_client_id() {
        $this->load_settings();
        return isset( $this->settings['bog_client_id'] ) ? trim( (string) $this->settings['bog_client_id'] ) : '';
    }

    public function get_client_secret() {
        $this->load_settings();
        return isset( $this->settings['bog_secret_key'] ) ? trim( (string) $this->settings['bog_secret_key'] ) : '';
    }

    private function get_access_token() {
        $client_id     = $this->get_client_id();
        $client_secret = $this->get_client_secret();

        if ( '' === $client_id || '' === $client_secret ) {
            return new WP_Error(
                'wi_bog_missing_settings',
                'BOG: Client ID და Client Secret აუცილებელია. შეავსე პარამეტრებში.'
            );
        }

        $auth = base64_encode( $client_id . ':' . $client_secret );

        $response = wp_remote_post(
            self::AUTH_URL,
            [
                'timeout'     => 30,
                'redirection' => 0,
                'headers'     => [
                    'Authorization' => 'Basic ' . $auth,
                    'Content-Type'  => 'application/x-www-form-urlencoded',
                    'Accept'        => 'application/json',
                ],
                'body'        => 'grant_type=client_credentials',
            ]
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code     = (int) wp_remote_retrieve_response_code( $response );
        $body_raw = wp_remote_retrieve_body( $response );
        $body     = json_decode( $body_raw, true );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'wi_bog_token_failed',
                'BOG: token მიღება ვერ მოხერხდა. HTTP ' . $code,
                [
                    'response_code' => $code,
                    'response_body' => $body_raw,
                    'request_url'   => self::AUTH_URL,
                ]
            );
        }

        if ( empty( $body['access_token'] ) ) {
            return new WP_Error( 'wi_bog_token_missing', 'BOG: access_token პასუხში არ მოვიდა.' );
        }

        return (string) $body['access_token'];
    }

    public function create_application( array $data ) {
        $token = $this->get_access_token();
        if ( is_wp_error( $token ) ) {
            return $token;
        }

        $admin_base   = admin_url( 'admin.php?page=wi-installments-hub-bog' );
        $success_url  = add_query_arg( 'bog_status', 'success', $admin_base );
        $fail_url     = add_query_arg( 'bog_status', 'fail', $admin_base );
        $callback_url = str_replace( 'http://', 'https://', admin_url( 'admin-ajax.php?action=wi_bog_callback' ) );

        $unit_price = (float) $data['price_total'];
        $quantity   = max( 1, (int) $data['quantity'] );

        $payload = [
            'callback_url'      => $callback_url,
            'external_order_id' => (string) $data['invoice_id'],
            'purchase_units'    => [
                'currency'     => 'GEL',
                'total_amount' => round( $unit_price, 2 ),
                'basket'       => [
                    [
                        'product_id'  => (string) $data['invoice_id'],
                        'quantity'    => $quantity,
                        'unit_price'  => round( $unit_price / $quantity, 2 ),
                        'description' => sanitize_text_field( (string) $data['product_name'] ),
                    ],
                ],
            ],
            'redirect_urls'     => [
                'success' => $success_url,
                'fail'    => $fail_url,
            ],
            'payment_method'    => [ 'bog_loan' ],
            'config'            => [
                'loan' => [
                    'type'  => isset( $data['bog_installment_type'] ) ? (string) $data['bog_installment_type'] : 'STANDARD',
                    'month' => isset( $data['bog_installment_month'] ) ? (int) $data['bog_installment_month'] : 12,
                ],
            ],
        ];

        $headers = [
            'Authorization'   => 'Bearer ' . $token,
            'Content-Type'    => 'application/json',
            'Accept'          => 'application/json',
            'Accept-Language' => 'ka',
        ];

        $response = wp_remote_post(
            self::ORDERS_URL,
            [
                'timeout'     => 30,
                'redirection' => 0,
                'headers'     => $headers,
                'body'        => wp_json_encode( $payload ),
            ]
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code             = (int) wp_remote_retrieve_response_code( $response );
        $body_raw         = wp_remote_retrieve_body( $response );
        $body             = json_decode( $body_raw, true );
        $headers_response = wp_remote_retrieve_headers( $response );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'wi_bog_create_failed',
                'BOG: შეკვეთის შექმნა ვერ მოხერხდა. HTTP ' . $code,
                [
                    'response_code'    => $code,
                    'response_body'    => $body_raw,
                    'response_headers' => $this->headers_to_array( $headers_response ),
                    'request_payload'  => $payload,
                    'request_url'      => self::ORDERS_URL,
                ]
            );
        }

        $order_id     = '';
        $redirect_url = '';

        if ( is_array( $body ) ) {
            $order_id = ! empty( $body['id'] ) ? (string) $body['id'] : '';

            if ( ! empty( $body['_links']['redirect']['href'] ) ) {
                $candidate = (string) $body['_links']['redirect']['href'];
                if ( filter_var( $candidate, FILTER_VALIDATE_URL ) ) {
                    $redirect_url = $candidate;
                }
            }
        }

        return [
            'request_url'       => self::ORDERS_URL,
            'request_method'    => 'POST',
            'request_headers'   => $headers,
            'request_payload'   => $payload,
            'response_code'     => $code,
            'response_body'     => is_array( $body ) ? $body : [],
            'response_body_raw' => $body_raw,
            'response_headers'  => $this->headers_to_array( $headers_response ),
            'session_id'        => $order_id,
            'redirect_url'      => $redirect_url,
        ];
    }

    public function get_application_status( array $request ) {
        $order_id = isset( $request['session_id'] ) ? trim( (string) $request['session_id'] ) : '';

        if ( '' === $order_id ) {
            return new WP_Error( 'wi_bog_missing_order_id', 'BOG: order_id (session_id) ცარიელია.' );
        }

        $token = $this->get_access_token();
        if ( is_wp_error( $token ) ) {
            return $token;
        }

        $endpoint = self::RECEIPT_URL . rawurlencode( $order_id );

        $headers = [
            'Authorization' => 'Bearer ' . $token,
            'Accept'        => 'application/json',
        ];

        $response = wp_remote_get(
            $endpoint,
            [
                'timeout'     => 30,
                'redirection' => 0,
                'headers'     => $headers,
            ]
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code             = (int) wp_remote_retrieve_response_code( $response );
        $body_raw         = wp_remote_retrieve_body( $response );
        $body             = json_decode( $body_raw, true );
        $headers_response = wp_remote_retrieve_headers( $response );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'wi_bog_status_failed',
                'BOG: სტატუსის მიღება ვერ მოხერხდა. HTTP ' . $code,
                [
                    'response_code'    => $code,
                    'response_body'    => $body_raw,
                    'response_headers' => $this->headers_to_array( $headers_response ),
                    'request_url'      => $endpoint,
                ]
            );
        }

        $status_map = [
            'completed'  => 'განვადება გააქტიურდა',
            'rejected'   => 'განვადება არ დამტკიცდა',
            'refunded'   => 'თანხა დაბრუნდა',
            'timeout'    => 'ვადა გავიდა',
            'processing' => 'მიმდინარეობს',
        ];

        $raw_status = '';
        if ( is_array( $body ) && ! empty( $body['order_status']['key'] ) ) {
            $raw_status = strtolower( (string) $body['order_status']['key'] );
        }

        $status_description = isset( $status_map[ $raw_status ] ) ? $status_map[ $raw_status ] : $raw_status;

        if ( is_array( $body ) ) {
            $body['statusId']          = $raw_status;
            $body['statusDescription'] = $status_description;
        }

        return [
            'request_url'       => $endpoint,
            'request_method'    => 'GET',
            'request_headers'   => $headers,
            'response_code'     => $code,
            'response_body'     => is_array( $body ) ? $body : [],
            'response_body_raw' => $body_raw,
            'response_headers'  => $this->headers_to_array( $headers_response ),
        ];
    }

    private function headers_to_array( $headers ) {
        if ( is_object( $headers ) && method_exists( $headers, 'getAll' ) ) {
            return $headers->getAll();
        }
        return is_array( $headers ) ? $headers : [];
    }
}
