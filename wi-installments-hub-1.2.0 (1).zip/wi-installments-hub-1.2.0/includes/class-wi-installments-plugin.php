<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WI_Installments_Plugin {
    private static $instance;
    private $logger;
    private $providers = [];
    private $admin;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct() {
        $this->logger = new WI_Installments_Logger();
        $this->providers['tbc'] = new WI_Provider_TBC( $this->logger );
        $this->providers['credo'] = new WI_Provider_Credo( $this->logger );
        $this->providers['bog']   = new WI_Provider_BOG( $this->logger );
        $this->admin = new WI_Installments_Admin( $this->logger, $this->providers );
    }
}
