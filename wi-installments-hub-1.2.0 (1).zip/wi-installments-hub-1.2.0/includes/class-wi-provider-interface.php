<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

interface WI_Provider_Interface {
    public function get_key();
    public function get_label();
    public function is_enabled();
    public function get_mode();
    public function create_application( array $data );
    public function get_application_status( array $request );
}
