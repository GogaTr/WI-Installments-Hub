# WI Installments Hub

WordPress/WooCommerce პლაგინი განვადების მოთხოვნების ადმინ პანელიდან ხელით შექმნისა და მართვისთვის.

## მხარდაჭერილი პროვაიდერები

- **TBC** — TBC Online Installments API (test/production გადართვა)
- **Credo** — Credo განვადება (ganvadeba.credo.ge)
- **საქართველოს ბანკი (BOG)** — Payments Manager API (installment-v2.bog.ge)

## ფუნქციონალი

- განვადების მოთხოვნის ხელით შექმნა wp-admin-იდან
- მოთხოვნების ისტორია და სტატუსის შემოწმება
- HTTP request/response-ის სრული ლოგირება (DB + ფაილი)
- Sensitive header-ების ავტომატური mask-ება ლოგებში
- პროვაიდერების მარტივად გაფართოება interface-ის საშუალებით

## ინსტალაცია

1. ZIP ატვირთე WordPress plugins-ში და გააქტიურე
2. გახსენი **განვადებები → პარამეტრები** და შეავსე სასურველი პროვაიდერის რეკვიზიტები
3. გადადი პროვაიდერის გვერდზე და შექმენი მოთხოვნა

## BOG კონფიგურაცია

პარამეტრებში საჭიროა:
- **Client ID** და **Client Secret** — `businessmanager.bog.ge`-დან
- BOG Enabled ჩექბოქსი

განვადების **თვეები** და **ტიპი** (STANDARD / ZERO / DISCOUNTED) ყოველი მოთხოვნისას ფორმაში მიეთითება.

## TBC კონფიგურაცია

- API Key, API Secret, Merchant Key, Campaign ID
- Test ან Production გარემოს არჩევა

## Credo კონფიგურაცია

- Merchant ID და Secret Password
- Credo Enabled ჩექბოქსი

## ბაზის ცხრილები

პლაგინის გააქტიურებისას იქმნება:

- `wp_wi_installment_requests` — ყოველი განაცხადის სრული ჩანაწერი
- `wp_wi_installment_logs` — HTTP გამოძახებების ლოგი

ლოგ ფაილები: `wp-content/uploads/wi-installments-logs/`

## ახალი პროვაიდერის დამატება

1. შექმენი `includes/class-wi-provider-xxx.php` და დაიმპლემენტირე `WI_Provider_Interface`
2. `wi-installments-hub.php`-ში დაამატე `require_once`
3. `class-wi-installments-plugin.php`-ში დაარეგისტრირე `$this->providers['xxx']`
4. `class-wi-installments-admin.php`-ში დაამატე submenu და settings

## Changelog

### 1.2.0
- საქართველოს ბანკი (BOG) provider — Payments Manager API
- განვადების თვეები და ტიპი ფორმაში (per-request)

### 1.1.0
- Credo provider
- Dashboard გვერდი

### 1.0.1
- TBC redirect URL handling fix
